# RapidWebHomework2018

Starter Code for Rapid web homework 1.

## What to do

Since this is some dummy data, change everything to reflect you and that's it!

### Deadline
End of today 04/17 or First thing tomorrow 04/18

Tenkiuu

